<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Sobre nós!</title>

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,600;1,700&family=Inter:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Cardo:ital,wght@0,400;0,700;1,400&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="css/main.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: PhotoFolio
  * Updated: Jul 27 2023 with Bootstrap v5.3.1
  * Template URL: https://bootstrapmade.com/photofolio-bootstrap-photography-website-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header d-flex align-items-center fixed-top">
    <div class="container-fluid d-flex align-items-center justify-content-between">

      <a href="index.php" class="logo d-flex align-items-center  me-auto me-lg-0">
        <img src="img/Lar.png" alt="gatinho azul ciano com nome Lar RonRom">
        <h1>Lar Ronrom</h1>
      </a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a href="index.php">Início</a></li>
          <li><a href="about.php" class="active">Sobre nós!</a></li>
          <li><a href="contact.php">Contate-nos!</a></li>
          <li><a href="login.php" class="active">Login</a></li>
        </ul>
      </nav><!-- .navbar -->

      <div class="header-social-links">
        <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
        <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
        <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
      </div>
      <i class="mobile-nav-toggle mobile-nav-show bi bi-list"></i>
      <i class="mobile-nav-toggle mobile-nav-hide d-none bi bi-x"></i>

    </div>
  </header><!-- End Header -->

  <main id="main" data-aos="fade" data-aos-delay="1500">

    <!-- ======= End Page Header ======= -->

    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-6 text-center">
          <h2>Sobre nós!</h2><br>
          <p>Somos uma equipe de jovens com o objetivo de melhorar a vida de gatinhos sem lar e que precisam de cuidados especiais. Lutamos pela qualidade de vida dos nossos felinos e contamos com a sua ajuda para tornar a vida de um deles muito melhor!
          </p>
      </div>
    </div>
    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container">

        <div class="row gy-4 justify-content-center">
          <div class="col-lg-4">
            <img src="img/sobre.jpg" class="img-fluid" alt="">
          </div>
          <div class="col-lg-5 content">
            <h2>Informações sobre o Lar Ronrom:</h2>
            <div class="row">
              <div class="col-lg-6">
                <ul>
                  <li><i class="bi bi-chevron-right"></i> <strong>Fundado em:</strong> <span>14/03/2002</span></li>
                  <li><i class="bi bi-chevron-right"></i> <strong>Site:</strong> <span>www.lar.ronrom.com</span></li>
                  <li><i class="bi bi-chevron-right"></i> <strong>Telefone:</strong> <span>11 98765-4321</span></li>
                  <li><i class="bi bi-chevron-right"></i> <strong>Cidade:</strong> <span>Jundiaí - SP</span></li>
                  <li><i class="bi bi-chevron-right"></i> <strong>E-mail:</strong> <span>lar.ronrom@gmail.com</span></li>
                </ul>
              </div>
            </div>
            <p class="py-3">
              No Lar Ronrom, os gatinhos são tratados da melhor maneira possível e todos os custos vêm de doações dos nossos parceiros e contribuintes. Todos os gatinhos são vacinados e vermifugados assim que nós os recebemos. 

            </p>
            <p class="m-0">
              Precisamos da sua ajuda para que eles tenham uma vida mais digna em um lar próprio, onde eles vão receber e dar muito amor. Faça a sua parte,  adote um Ronrom!
Caso você não tenha condições de adotar, também recebemos doações em dinheiro ou produtos!</p>

          </div>
        </div>

      </div>
    </section><!-- End About Section -->

    <!-- ======= Testimonials Section ======= -->
    <section id="testimonials" class="testimonials">
      <div class="container">

        <div class="section-header">
          <h1>Nossa equipe!</h1><br>
          <h3>Quem somos nós?</h3>
        </div>

        <div class="slides-3 swiper">
          <div class="swiper-wrapper">

            <div class="swiper-slide">
              <div class="testimonial-item">
                <p>
                  Meu nome é Maria Clara e tenho 22 anos. Estou estudando medicina veterinária e sou responsável pelo resgate dos gatinhos que nós ajudamos diariamente.
                </p>
                <div class="profile mt-auto">
                  <img src="img/resgate1.jpg" class="testimonial-img" alt="">
                  <h3>Maria Clara</h3>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <p>
                  Olá, me chamo Pedro Soares e sou responsável pela administração das redes sociais da ONG e também cuido das questões finaieiras, como doações e gastos.
                </p><br>
                <div class="profile mt-auto">
                  <img src="img/redes.jpg" class="testimonial-img" alt="">
                  <h3>Pedro Soares</h3>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <p>
                  Olá, meu nome é Jonathan Souza. Sou bombeiro há oito anos e meu sonho desde pequeno sempre foi ajudar os animaizinhos que precisam. Hoje, junstamente com a Maria Clara, faço o resgate dos bichinhos que estão numa situação difícil para que eles recebam todo o amor que merecem.
                </p>
                <div class="profile mt-auto">
                  <img src="img/resgate2.jpg" class="testimonial-img" alt="">
                  <h3>Jonathan Souza</h3>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <p>
                    Meu nome é Miriam Leite, sou veterinária há dez anos e me dedico aos cuidados dos Ronrons fora do meu expediente. Amo muito esses bichinhos e faço o máximo para que eles tenham a melhor vida possível.
                </p>
                <div class="profile mt-auto">
                  <img src="img/veterinaria.jpg" class="testimonial-img" alt="">
                  <h3>Miriam Leite</h3>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <p>
                  Quis quorum aliqua sint quem legam fore sunt eram irure aliqua veniam tempor noster veniam enim culpa labore duis sunt culpa nulla illum cillum fugiat legam esse veniam culpa fore nisi cillum quid.
                </p>
                <div class="profile mt-auto">
                  <img src="img/veterinario.jpg" class="testimonial-img" alt="">
                  <h3>Nicolas Lima</h3>
                </div>
              </div>
            </div><!-- End testimonial item -->

          </div>
          <div class="swiper-pagination"></div>
        </div>

      </div>
    </section><!-- End Testimonials Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>PhotoFolio</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/photofolio-bootstrap-photography-website-template/ -->
        Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a><br>
        <b><i>Lucas Siqueira, Maria Fernanda e Noemy Lima<br> Turma B</i></b>
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <div id="preloader">
    <div class="line"></div>
  </div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>