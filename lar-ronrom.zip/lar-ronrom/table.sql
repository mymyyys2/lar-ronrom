create database ong;
use ong;
create table usuario (
nome varchar(40),
email varchar(255) primary key,
senha varchar(255));
select * from usuario;

CREATE TABLE gatos (
    id INT NOT NULL AUTO_INCREMENT, 
    sexo VARCHAR(1) NOT NULL, 
    nome VARCHAR(45) NOT NULL, 
    descricao VARCHAR(90) NOT NULL, 
    imagem VARCHAR(80) NOT NULL, 
    idade VARCHAR(50) NOT NULL,
PRIMARY KEY (id));

select * from gatos;

INSERT INTO gatos (imagem, nome, sexo, idade, descricao) VALUES ('img/gato1.jpg', 'Frankeinstein', 'M', '1 ano de idade', 'castrado');
INSERT INTO gatos (imagem, nome, sexo, idade, descricao) VALUES ('img/gato2.jpg', 'Inox', 'M', '2 anos de idade', 'castrado');
INSERT INTO gatos (imagem, nome, sexo, idade, descricao) VALUES ('img/gato3.jpg', 'Kiara', 'F', '8 meses de idade', 'castradas');
INSERT INTO gatos (imagem, nome, sexo, idade, descricao) VALUES ('img/gato4.jpg', 'Thor, Tulipa e Tom', 'M, F, M', '1 mese de idade', 'ainda não castrados');
INSERT INTO gatos (imagem, nome, sexo, idade, descricao) VALUES ('img/gato5.jpg', 'Chico e Xande', 'M, M', '1 ano e  meio de idade', 'castrados');
INSERT INTO gatos (imagem, nome, sexo, idade, descricao) VALUES ('img/gato15.jpg', 'Amélia e Aladin', 'F, M', '2 meses de idade', 'ainda não castrados');
INSERT INTO gatos (imagem, nome, sexo, idade, descricao) VALUES ('img/gato7.jpg', 'Alfredo', 'M', '3 anos de idade', 'castrado');
INSERT INTO gatos (imagem, nome, sexo, idade, descricao) VALUES ('img/gato8.jpg', 'Ágatha', 'F', '2 anos de idade', 'castrada');
INSERT INTO gatos (imagem, nome, sexo, idade, descricao) VALUES ('img/gatos9.jpg', 'Frida, Finn e Felícia', 'F, M, F', '2 meses de idade', 'ainda não castrados');
INSERT INTO gatos (imagem, nome, sexo, idade, descricao) VALUES ('img/gato11.jpg', 'Cindy', 'F', '5 anos de idade', 'castrada');
INSERT INTO gatos (imagem, nome, sexo, idade, descricao) VALUES ('img/gatos16.jpg', 'Bella, Babalu e Bartolomeu', 'F, F, M', '2 anos de idade', 'castrados');
INSERT INTO gatos (imagem, nome, sexo, idade, descricao) VALUES ('img/gatos18.jpg', 'Jade, Jordan e Jolie', 'F, M ,F', '3 meses, 6 meses e 8 meses', 'castrados');
INSERT INTO gatos (imagem, nome, sexo, idade, descricao) VALUES ('img/gato2.jpg', 'Inox', 'M', '2 anos de idade', 'castrado');
