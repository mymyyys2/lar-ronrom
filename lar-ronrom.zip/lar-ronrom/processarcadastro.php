<?php
require_once "conexao.php";

// Verifique se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["cadastro"])) {
    // Obtenha os dados do formulário
    $nome = $_POST["nome"];
    $email = $_POST["email"];
    $senha = $_POST["senha"];

    // Inserir os dados na tabela 'usuario'
    $sql = "INSERT INTO usuario (nome, email, senha) VALUES ('$nome', '$email', '$senha')";

    if ($conn->query($sql) === TRUE) {
        header("Location: login.php");
        exit();
    } else {
        echo "Erro ao cadastrar o usuário: " . $conn->error;
    }
} else {
    // Se o formulário não foi enviado corretamente, redirecione ou exiba uma mensagem de erro.
    echo "Erro: O formulário não foi enviado corretamente.";
}
$conn->close();
?>
